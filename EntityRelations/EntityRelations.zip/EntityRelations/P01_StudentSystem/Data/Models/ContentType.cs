﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        application = 10,
        pdf = 20,
        zip = 30
    }
}