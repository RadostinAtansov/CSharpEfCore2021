﻿namespace P01_StudentSystem.Data.Models
{
    public enum ResourceType
    {
            Video = 10,
            Presentation = 22,
            Document = 30,
            Other = 40
    }
}