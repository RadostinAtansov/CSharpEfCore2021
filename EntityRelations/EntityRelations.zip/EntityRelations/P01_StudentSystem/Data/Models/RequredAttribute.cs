﻿using System;

namespace P01_StudentSystem.Data.Models
{
    internal class RequredAttribute : Attribute
    {
    }
}